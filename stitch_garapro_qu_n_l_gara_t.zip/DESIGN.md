---
name: GaraPro
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3d4947'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6d7a77'
  outline-variant: '#bcc9c6'
  surface-tint: '#006a61'
  primary: '#00685f'
  on-primary: '#ffffff'
  primary-container: '#008378'
  on-primary-container: '#f4fffc'
  inverse-primary: '#6bd8cb'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#595c5e'
  on-tertiary: '#ffffff'
  tertiary-container: '#727577'
  on-tertiary-container: '#fbfdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#89f5e7'
  primary-fixed-dim: '#6bd8cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies a modern, professional, and utilitarian Enterprise SaaS aesthetic tailored for automotive garage management. The brand personality is rooted in reliability, efficiency, and operational clarity. It instills trust through an uncluttered, purposeful layout that minimizes cognitive load for technicians, service advisors, and shop managers. 

The visual style is clean and structured, utilizing deliberate information hierarchy, soft tonal layering, and precise typography to handle dense data sets—such as parts inventories, repair orders, and customer schedules—without feeling overwhelming.

## Colors

The color palette establishes a calm, professional operational environment. A very light gray background (`#F8FAFC`) provides a comfortable canvas for extended data entry sessions, reducing eye strain. The deep navy sidebar (`#0F172A`) grounds the navigation hierarchy, while the vibrant teal primary accent (`#0D9488`) draws attention to primary calls to action, active states, and key metrics. 

Semantic colors are calibrated for high legibility in fast-paced workshop environments: amber (`#F59E0B`) for warnings and pending approvals, emerald (`#10B981`) for completed services and success states, and red (`#EF4444`) for critical alerts and error handling.

## Typography

Inter is chosen for its exceptional legibility, neutral aesthetic, and robust Vietnamese character support. The type scale relies on high-contrast weight transitions rather than extreme size shifts, ensuring that dense data tables, repair logs, and dashboard metrics remain scannable and precise across desktop and tablet viewports.

## Layout & Spacing

This design system uses a flexible 12-column fluid grid system optimized for desktop-first enterprise workflows, scaling down gracefully to tablet devices used on the shop floor. Content is structured within contained card modules separated by consistent gutters and outer margins to maximize information density while maintaining visual breathing room.

- **Breakpoints:** Desktop (`1200px+`), Tablet (`768px - 1199px`), Mobile (`<768px`).
- **Reflow Rules:** On tablet and mobile viewports, multi-column form layouts and wide data tables stack vertically or transition to horizontally scrollable containers with fixed lead columns.

## Elevation & Depth

Visual hierarchy is achieved through a combination of tonal layering and low-contrast outlines. Avoid heavy drop shadows; instead, use subtle surface elevation tiers to separate floating elements like modals, dropdown menus, and sticky table headers from the base canvas. 

- **Base Layer:** `#F8FAFC` for background canvases.
- **Surface Layer:** `#FFFFFF` for primary cards, containers, and data panels.
- **Borders:** `#E2E8F0` for crisp, low-contrast structural dividers and component outlines.

## Shapes

A balanced, modern roundedness level (`rounded-lg` / `rounded-xl`) is applied across all UI elements to soften the utilitarian density of the enterprise application. Interactive elements, cards, and input fields feature friendly, approachable radii that prevent the interface from feeling overly rigid while maintaining professional precision.

## Components

### Buttons
- **Primary:** Solid teal background (`#0D9488`) with white text, medium weight, and soft rounded corners. Hover states darken slightly to `#0F766E`.
- **Secondary:** Outlined with a subtle border (`#E2E8F0`) and neutral dark text over a white surface.
- **Destructive:** Solid or outlined red (`#EF4444`) for critical actions like deleting work orders or revoking user access.

### Chips & Badges
- Used extensively for status indicators (e.g., "In Progress", "Completed", "Waiting for Parts"). Utilize light semantic background tints paired with matching dark text for instant scanning.

### Input Fields & Forms
- Clean bordered inputs with a white background, subtle gray borders, and teal focus rings. Labels are placed clearly above inputs with helper text below for validation errors.

### Tables & Lists
- Designed for high-density data management. Features subtle horizontal dividers, sticky headers for long lists, and compact row heights to display maximum vehicle and customer data without excessive scrolling.

### Checkboxes & Radio Buttons
- Standardized controls utilizing the primary teal accent for checked states, ensuring clear multi-select capabilities for inventory items and service checklists.

### Cards & Containers
- White surfaces bounded by fine borders and soft corner radii, used to group related information such as customer profiles, vehicle inspection summaries, and invoice totals.

### Additional Components
- **Data Grids & Kanban Boards:** For tracking repair order workflows from intake to final quality check.
- **Inventory Steppers:** Quick quantity adjusters for auto parts management.
- **Diagnostic Timeline:** Vertical step indicators tracking multi-stage vehicle repair milestones.